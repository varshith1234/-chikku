# Storage Account

This module will deploy a Storage Account with Private Endpoint, Network Rules and Microsoft.Storage Service Endpoint.

## Variables

See `variables.tf` for a description of values that can be provided to the module.

## storage-account-pipeline.yml

See the `storage-account-pipeline.yml` directory for example usage.
