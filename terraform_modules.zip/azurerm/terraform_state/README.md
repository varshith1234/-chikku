# Terraform State

This module will deploy a Storage Account and Container suitable for Terraform Remote State.

## Variables

See `variables.tf` for a description of values that can be provided to the module.

## Outputs

See `outputs.tf` for a list of resources and properties output by this module.

## Example

See the `examples` directory for example usage.
