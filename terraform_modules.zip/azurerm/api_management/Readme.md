# API Management

This module will define a standard API Management resource.

## Files

| File Name | Description |
| --- | --- |
| `variables.tf` | Module Variables |
| `outputs.tf`   | Output Variables |
| `versions.tf`  | Terraform software and provider requirements |
| `main.tf`      | Main resource definitions |

## Example Usage
```
module "api_management" {
  source              = "../../modules/api_management"
  tags                = local.common_tags
  resource_group_name = azurerm_resource_group.api_management.name
  location            = var.location
  name                = "nt${lower(var.env)}hub${lower(local.loc_code)}-APIM"
  publisher_name      = "Northern Trust GDWM/GPI" # who?
  publisher_email     = "mtm10@ntrs.com"          # which email?
  sku_name            = "Developer_1" 
  policy_xml_content  = <<XML
    <policies>
      <inbound />
      <backend />
      <outbound />
      <on-error />
    </policies>
  XML
  application_type = "other"
  virtual_network_type = "External"
  subnet_id = "/subscriptions/cd1e5618-2229-4ead-960c-35d37cbff61e/resourceGroups/CUS-BU2-X-NET-RG/providers/Microsoft.Network/virtualNetworks/CUS-BU2-X-VNET/subnets/APIManagement"
}
