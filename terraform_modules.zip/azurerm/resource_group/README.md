# Resource Group

This module will deploy an Azure Resource Group.

## Variables

See `variables.tf` for a description of values that can be provided to the module.


