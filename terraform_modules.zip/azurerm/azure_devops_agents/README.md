# Azure DevOps Agents Scale Set (This is only in preview)

This module will deploy a Linux Scale Set suitable for Azure DevOps Agents.

## Variables

See `variables.tf` for a description of values that can be provided to the module.

## Outputs

See `outputs.tf` for a list of resources and properties output by this module.

## Example

See the `examples` directory for example usage.
