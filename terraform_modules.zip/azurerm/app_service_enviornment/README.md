# Azure App service Environment

This module will deploy an Azure App Service Environment.

## Variables

See `variables.tf` for a description of values that can be provided to the module.

## Outputs

See `outputs.tf` for a list of resources and properties output by this module.

## Script

See the `main.tf` to create Azure App service environment
